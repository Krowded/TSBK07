
These scenes have textures which are hand-drawn to fit with the
gemetry. Each model file has an accompanying texture with the same
name.

The reason why each model has been split into multiple model files, is
because different parts of the model used different textures, and
splitting the model itself makes it easy for the user to switch active
texture at the right moment during rendering.

These models are intended to be rendered without any dynamic lighting.
